//
//  BuychannelApi.h
//  Pods-SDK_Buychannel_oc_Example
//
//  Created by 张亮 on 2019/11/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark BuyChannelDelegate
@protocol BuyChannelDelegate <NSObject>

@optional

/*
 回调买量状态
 */
- (void)onBuyChannelSuccess:(NSString *)buyChannel userFrom:(NSInteger)userFrom;
- (void)onBuyChannelFailure:(NSError *)error;
@end

@interface BuychannelApi : NSObject

/**
 在 didFinishLaunchingWithOptions 函数中调用
 */
+(void) setupWithAppsflyerkey:(NSString *) key appId:(NSString *) appId;

/**
 在applicationDidBecomeActive 函数中添调用
 */
+(void) trackAppLaunch;

/** 获取买量渠道 */
+(NSString *) buychannel;

 /** 是否是买量用户 */
+(BOOL) isUserBuy;

/**
 用户来源，是二级用户类型，对应的数字关系
 gp 自然         -> -1
 自然带量         -> 0
 GA买量          -> 1
 FB自投          -> 2
 FB非自投         -> 3
 Adwords自投      -> 4
 Adwords非自投    -> 6
 非自然带量        -> 7
 非GP自然         -> 8
 未知买量         -> 9
 */
+(NSInteger) userFrom;

/** 设置买量监听 */
+(void) delegate:(id) delegate;

/** 开启log */
+(void) logEnable:(BOOL) enable;

@end

NS_ASSUME_NONNULL_END
